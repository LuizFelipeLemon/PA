g++ -g -Wall -I/ Produto.cpp Livro.cpp Loja.cpp CD.cpp DVD.cpp ListaLivro.cpp ListaCD.cpp ListaDVD.cpp main.cpp -o test
./test